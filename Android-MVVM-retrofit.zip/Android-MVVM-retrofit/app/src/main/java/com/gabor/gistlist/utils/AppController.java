package com.gabor.gistlist.utils;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.snackbar.Snackbar;

public class AppController extends Application /*SugarApp*/ {
    private static Context context;
    public static boolean activityVisible;
    private static AppController mInstance;
    public static String PACKAGE_NAME;//new int[]

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        AppController.context = getApplicationContext();
        PACKAGE_NAME = getApplicationContext().getPackageName();
    }

    public static void activityResumed() {
        activityVisible = true;
    }

    public static void activityPaused() {
        activityVisible = false;
    }

    public static void doRoate(View view, int degree, int time, int rotationCount, Boolean start) {
        RotateAnimation rotate = new RotateAnimation(
                0, degree,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        if (start) {
            rotate.setDuration(time);
            rotate.setRepeatCount(rotationCount);
            view.startAnimation(rotate);
        } else {
            rotate.setRepeatCount(0);
        }
    }

    public static int dpToPx(int dp) {
        float density = AppController.getAppContext().getResources()
                .getDisplayMetrics()
                .density;
        return Math.round((float) dp * density);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        //MultiDex.install(this);
    }

    public static Context getAppContext() {
        return AppController.context;
    }

    public static void doToast(String str) {
        Toast aToast = Toast.makeText(AppController.getAppContext(), str, Toast.LENGTH_LONG);
        aToast.show();
    }

    public static void setStatusBarTranslucent(boolean makeTranslucent, Activity activity) {
        if (makeTranslucent) {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
                activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            }
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    public static void doSnackBar(String str, Context context, View parent, int color, boolean indefinite) {
        if (context != null) {
            Snackbar snackbar;
            snackbar = Snackbar.make(parent, str, 10000);
            View sbView = snackbar.getView();
            sbView.setBackgroundColor(Color.parseColor(context.getString(color)));
            ((TextView) (sbView.findViewById(com.google.android.material.R.id.snackbar_text))).setTextColor(Color.WHITE);
            snackbar.show();
        }
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

    public static synchronized AppController getInstance() {
        return mInstance;
    }

}