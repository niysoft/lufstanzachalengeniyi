Displays the top public gists from Github. 

![Demo](http://i.giphy.com/3o7TKW0nrNSwdar7Ms.gif)




